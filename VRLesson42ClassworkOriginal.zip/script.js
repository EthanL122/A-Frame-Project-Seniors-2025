let rnd = (l,u) => Math.floor(Math.random()*(u-l)+l);
window.onload = function(){
  scene = document.querySelector("a-scene");
  

}